﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Atol.Drivers10.Fptr;
namespace AppAtol
{
    /// <summary>
    /// Логика драть ее  за ногу ;))
    /// </summary>
   public class BL
    {
        
        /// <summary>
        /// Попытка соединения с др
        /// </summary>
        /// <returns></returns>
        public bool OpenKKM()
        {
            IFptr fptr = new Fptr();

            bool isOpened = fptr.isOpened();

            if (isOpened !=false)
            {
                return isOpened;
            }
            fptr.open();

            return false;
        }

        /// <summary>
        /// Печать Х отчета
        /// </summary>
        public void Print_X_Report()
        {
            IFptr fptr = new Fptr();
            fptr.open();

            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_X);
            fptr.report();
        }
        /// <summary>
        /// Напечатать последний документ из ККМ
        /// </summary>
        public void Print_Last_Document()
        {
            IFptr fptr = new Fptr();
            fptr.open();

            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_LAST_DOCUMENT);
            fptr.report();
        }

        /// <summary>
        /// Напечатать информацию о ккм
        /// </summary>
        public void Print_Infa_KKM()
        {
            IFptr fptr = new Fptr();
            fptr.open();

            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_KKT_INFO);
            fptr.report();
        }
        /// <summary>
        /// Печатать Тест ОФД
        /// </summary>
        public void Print_OFD_Test()
        {
            IFptr fptr = new Fptr();
            fptr.open();

            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_OFD_TEST);
            fptr.report();
        }

        /// <summary>
        /// Напечатать чек по номеру из ФН
        /// </summary>
        /// <param name="value_Num"></param>
        public void Print_Number_FN(int value_Num = 1) // по умолчанию 1 чек. Чек Регистрации
        {
            IFptr fptr = new Fptr( );
            fptr.open();

            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_FN_DOC_BY_NUMBER);
            fptr.setParam(Constants.LIBFPTR_PARAM_DOCUMENT_NUMBER, value_Num);
            fptr.report();
        }

        /// <summary>
        /// Печать итогов регистрации / перерегистрации
        /// </summary>
        public void Print_End_FN_Registrations()
        {
            IFptr fptr = new Fptr();
            fptr.open();

            fptr.setParam(Constants.LIBFPTR_PARAM_REPORT_TYPE, Constants.LIBFPTR_RT_FN_REGISTRATIONS);
            fptr.report();
        }

        /// <summary>
        /// Регистрационные данные о ККТ
        /// </summary>
        /// <returns></returns>
        public string Registration_Data_KKT()
        {
            IFptr fptr = new Fptr();
            fptr.open();

            fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_REG_INFO);
            fptr.fnQueryData();

            uint taxationTypes = fptr.getParamInt(1062);
            uint agentSign = fptr.getParamInt(1057);
            uint ffdVersion = fptr.getParamInt(1209);

            bool autoModeSign = fptr.getParamBool(1001);
            bool offlineModeSign = fptr.getParamBool(1002);
            bool encryptionSign = fptr.getParamBool(1056);
            bool internetSign = fptr.getParamBool(1108);
            bool serviceSign = fptr.getParamBool(1109);
            bool bsoSign = fptr.getParamBool(1110);
            bool lotterySign = fptr.getParamBool(1126);
            bool gamblingSign = fptr.getParamBool(1193);
            bool exciseSign = fptr.getParamBool(1207);
            bool machineInstallationSign = fptr.getParamBool(1221);

            string fnsUrl = fptr.getParamString(1060);
            string organizationVATIN = fptr.getParamString(1018);
            string organizationName = fptr.getParamString(1048);
            string organizationEmail = fptr.getParamString(1117);
            string paymentsAddress = fptr.getParamString(1187);
            string registrationNumber = fptr.getParamString(1037);
            string machineNumber = fptr.getParamString(1036);
            string ofdVATIN = fptr.getParamString(1017);
            string ofdName = fptr.getParamString(1046);

            string infaKKM = $"Реквизиты регистрации ККТ:\t\n" +
                $"ИНН организации:{organizationVATIN} \t\n" +
                $"Название организации:{organizationName} \t\n" +
                $"Адрес места расчетов:{paymentsAddress} \t\n" +
                $"E-mail организации:{organizationName} \t\n" +
                $"Регистрационный номер устройства:{registrationNumber} \t\n" +
                $"Версия ФФД:{ffdVersion} \t\n"+
                $"Название ОФД:{ofdName} \t\n" +
                $"ИНН ОФД:{ofdVATIN} \t\n"+
                $"Признак автоматического режима:{autoModeSign} \t\n"+
                $"Номер автомата:{machineNumber} \t\n" +
                $"Признак автономного режима:{offlineModeSign} \t\n" +
                $"Признак шифрования:{encryptionSign} \t\n" +
                $"Признак ККТ для расчетов в сети Интернет:{internetSign} \t\n" +
                $"Признак расчетов за услуги:{serviceSign} \t\n" +
                $"БСО (бланков строгой отчетности):{bsoSign} \t\n" +
                $"Признак проведения лотерей:{lotterySign} \t\n" +
                $"Признак проведения азартных игр:{gamblingSign} \t\n" +
                $"Признак установки принтера в автомате:{machineInstallationSign} \t\n" 
                ;

            return infaKKM;
        }


        public void Status_OBmenna_OFD()
        {
            IFptr fptr = new Fptr();
            fptr.open();

            fptr.setParam(Constants.LIBFPTR_PARAM_FN_DATA_TYPE, Constants.LIBFPTR_FNDT_OFD_EXCHANGE_STATUS);
            fptr.fnQueryData();

            uint exchangeStatus = fptr.getParamInt(Constants.LIBFPTR_PARAM_OFD_EXCHANGE_STATUS);
            uint unsentCount = fptr.getParamInt(Constants.LIBFPTR_PARAM_DOCUMENTS_COUNT);
            uint firstUnsentNumber = fptr.getParamInt(Constants.LIBFPTR_PARAM_DOCUMENT_NUMBER);
            bool ofdMessageRead = fptr.getParamBool(Constants.LIBFPTR_PARAM_OFD_MESSAGE_READ);
            DateTime dateTime = fptr.getParamDateTime(Constants.LIBFPTR_PARAM_DATE_TIME);

            string status_ofd = $"Статус информационного обмена ОФД.\t\n" +
                $"Количество неотправленных документов:{exchangeStatus} \t\n" +
                $"Номер первого неотправленного документа:{firstUnsentNumber} \t\n" +
                $"LIBFPTR_PARAM_DATE_TIME:{dateTime} \t\n"; //+
               // $"Флаг наличия сообщения для ОФД:{ofdMessageRead} \t\n" +
               // ;
        }
    }
}
